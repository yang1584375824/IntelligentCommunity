#include "yezhuguzhuangbaoxiu.h"
#include "ui_yezhuguzhuangbaoxiu.h"

extern int yonghuming;

Yezhuguzhuangbaoxiu::Yezhuguzhuangbaoxiu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Yezhuguzhuangbaoxiu)
{
    ui->setupUi(this);
    /**连接数据库**/
//        db=QSqlDatabase::addDatabase("QSQLITE");
//        db.setDatabaseName("wuye.db");
//        if(!db.open()){
//            QMessageBox::information(NULL,"提示","数据库连接失败",QMessageBox::Ok);
//        }else{
//            QMessageBox::information(NULL,"提示","数据库连接成功",QMessageBox::Ok);
//        }
}

Yezhuguzhuangbaoxiu::~Yezhuguzhuangbaoxiu()
{
    delete ui;
}

void Yezhuguzhuangbaoxiu::on_pushButton_2_clicked()
{
    QString name = ui->lineEdit->text();
    QString phone = ui->lineEdit_2->text();
    QString address= ui->lineEdit_3->text();
    QString issue= ui->textEdit->toPlainText();
    QString str = QString("insert into weixiu (name,phone,address,issue) values('%1','%2','%3','%4') ").arg(name).arg(phone).arg(address).arg(issue);
    QSqlQuery query;
    if(!query.exec(str))
    {
        QMessageBox::information(NULL,"Fault"," 信息写入失败！！");
    }
    else
    {
        QMessageBox::information(NULL,"Success"," 信息写入成功！！");
    }
}
