#ifndef SHENPI_H
#define SHENPI_H

#include <QWidget>

namespace Ui {
class Guanliyuanqingjiashenpi;
}

class Guanliyuanqingjiashenpi : public QWidget
{
    Q_OBJECT

public:
    explicit Guanliyuanqingjiashenpi(QWidget *parent = 0);
    ~Guanliyuanqingjiashenpi();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Guanliyuanqingjiashenpi *ui;
};

#endif // SHENPI_H
