#include "wuyejiaofeiguanli.h"
#include "ui_wuyejiaofeiguanli.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

extern int yonghuming;

Wuyejiaofeiguanli::Wuyejiaofeiguanli(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyejiaofeiguanli)
{
    ui->setupUi(this);
    //建立并打开数据库
//        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
//        db.setDatabaseName("jiaofeixinxi.db");
//    if (!db.open()) {
//        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
//            QObject::tr("不能建立链接n.\n"
//                        "This example needs SQLite support. Please read "
//                        "the Qt SQL driver documentation for information how "
//                        "to build it.\n\n"
//                        "Click Cancel to exit."), QMessageBox::Cancel);
//    }else{
//        qDebug()<<"数据库打开成功！ "<<endl;
//      //  ui->label_data->setText(tr("数据库打开成功"));
//    }
}

Wuyejiaofeiguanli::~Wuyejiaofeiguanli()
{
    delete ui;
}
void Wuyejiaofeiguanli::on_pushButton_clicked()
{

    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString type = ui->lineEdit->text();
    QString date = ui->lineEdit_2->text();
    if(type == "物业费")
    {
    QString sql = QString("select payment.*,tyde.wuye from payment inner join tyde on payment.id=tyde.userid where type='%1' and date = '%2'").arg(type).arg(date);
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);
    }
    else if(type == "车位费")
    {
    QString sql = QString("select payment.*,tyde.chewei from payment inner join tyde on payment.id=tyde.userid where type='%1' and date = '%2'").arg(type).arg(date);
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);
    }
    if(type == "维修费")
    {
    QString sql = QString("select payment.*,tyde.weixiu from payment inner join tyde on payment.id=tyde.userid where type='%1' and date = '%2'").arg(type).arg(date);
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);
    }
}

void Wuyejiaofeiguanli::on_pushButton_3_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString type = ui->lineEdit->text();
    QString date = ui->lineEdit_2->text();
    if(type == "物业费")
    {
    QString sql = QString("select payment.*,tyde.wuye from payment inner join tyde on payment.id=tyde.userid where (type='%1' and date = '%2') and state = '%3'").arg(type).arg(date).arg("0");
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);
    }
    else if(type == "车位费")
    {
    QString sql = QString("select payment.*,tyde.chewei from payment inner join tyde on payment.id=tyde.userid where (type='%1' and date = '%2') and state = '%3'").arg(type).arg(date).arg("0");
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);
    }
    if(type == "维修费")
    {
    QString sql = QString("select payment.*,tyde.weixiu from payment inner join tyde on payment.id=tyde.userid where (type='%1' and date = '%2') and state = '%3'").arg(type).arg(date).arg("0");
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);
    }
}
