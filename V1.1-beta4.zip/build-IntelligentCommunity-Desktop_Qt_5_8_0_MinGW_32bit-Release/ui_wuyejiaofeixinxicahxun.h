/********************************************************************************
** Form generated from reading UI file 'wuyejiaofeixinxicahxun.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WUYEJIAOFEIXINXICAHXUN_H
#define UI_WUYEJIAOFEIXINXICAHXUN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Wuyejiaofeixinxicahxun
{
public:
    QPushButton *pushButton;
    QLabel *label_3;
    QPushButton *pushButton_2;
    QTableView *tableView;
    QPushButton *pushButton_3;
    QLabel *label_4;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit_2;

    void setupUi(QWidget *Wuyejiaofeixinxicahxun)
    {
        if (Wuyejiaofeixinxicahxun->objectName().isEmpty())
            Wuyejiaofeixinxicahxun->setObjectName(QStringLiteral("Wuyejiaofeixinxicahxun"));
        Wuyejiaofeixinxicahxun->resize(651, 505);
        pushButton = new QPushButton(Wuyejiaofeixinxicahxun);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(160, 180, 93, 28));
        label_3 = new QLabel(Wuyejiaofeixinxicahxun);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 220, 72, 15));
        pushButton_2 = new QPushButton(Wuyejiaofeixinxicahxun);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(460, 470, 93, 28));
        tableView = new QTableView(Wuyejiaofeixinxicahxun);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(70, 240, 541, 211));
        pushButton_3 = new QPushButton(Wuyejiaofeixinxicahxun);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(350, 180, 93, 28));
        label_4 = new QLabel(Wuyejiaofeixinxicahxun);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(220, 0, 161, 91));
        horizontalLayoutWidget_2 = new QWidget(Wuyejiaofeixinxicahxun);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(80, 70, 451, 91));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_2->addWidget(label);

        lineEdit = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout_2->addWidget(lineEdit);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(horizontalLayoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit_2 = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout->addWidget(lineEdit_2);


        horizontalLayout_2->addLayout(horizontalLayout);


        retranslateUi(Wuyejiaofeixinxicahxun);
        QObject::connect(pushButton_2, SIGNAL(clicked()), Wuyejiaofeixinxicahxun, SLOT(close()));

        QMetaObject::connectSlotsByName(Wuyejiaofeixinxicahxun);
    } // setupUi

    void retranslateUi(QWidget *Wuyejiaofeixinxicahxun)
    {
        Wuyejiaofeixinxicahxun->setWindowTitle(QApplication::translate("Wuyejiaofeixinxicahxun", "Widget", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Wuyejiaofeixinxicahxun", "\346\237\245\350\257\242", Q_NULLPTR));
        label_3->setText(QApplication::translate("Wuyejiaofeixinxicahxun", "\346\237\245\350\257\242\347\273\223\346\236\234", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Wuyejiaofeixinxicahxun", "\351\200\200\345\207\272", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Wuyejiaofeixinxicahxun", "\346\234\252\347\274\264\350\264\271\346\237\245\350\257\242", Q_NULLPTR));
        label_4->setText(QApplication::translate("Wuyejiaofeixinxicahxun", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; color:#0055ff;\">\347\274\264\350\264\271\344\277\241\346\201\257\346\237\245\350\257\242</span></p></body></html>", Q_NULLPTR));
        label->setText(QApplication::translate("Wuyejiaofeixinxicahxun", "\347\261\273\345\236\213", Q_NULLPTR));
        label_2->setText(QApplication::translate("Wuyejiaofeixinxicahxun", "\346\227\266\351\227\264", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Wuyejiaofeixinxicahxun: public Ui_Wuyejiaofeixinxicahxun {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WUYEJIAOFEIXINXICAHXUN_H
