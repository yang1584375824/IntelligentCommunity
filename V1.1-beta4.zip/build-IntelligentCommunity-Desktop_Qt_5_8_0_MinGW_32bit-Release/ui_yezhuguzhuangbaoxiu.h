/********************************************************************************
** Form generated from reading UI file 'yezhuguzhuangbaoxiu.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YEZHUGUZHUANGBAOXIU_H
#define UI_YEZHUGUZHUANGBAOXIU_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Yezhuguzhuangbaoxiu
{
public:
    QLabel *label;
    QPushButton *pushButton_2;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_5;
    QTextEdit *textEdit;

    void setupUi(QWidget *Yezhuguzhuangbaoxiu)
    {
        if (Yezhuguzhuangbaoxiu->objectName().isEmpty())
            Yezhuguzhuangbaoxiu->setObjectName(QStringLiteral("Yezhuguzhuangbaoxiu"));
        Yezhuguzhuangbaoxiu->resize(700, 600);
        Yezhuguzhuangbaoxiu->setStyleSheet(QStringLiteral("background-image: url();"));
        label = new QLabel(Yezhuguzhuangbaoxiu);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(270, 50, 111, 41));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(16);
        label->setFont(font);
        pushButton_2 = new QPushButton(Yezhuguzhuangbaoxiu);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(280, 500, 71, 31));
        pushButton_2->setFont(font);
        layoutWidget = new QWidget(Yezhuguzhuangbaoxiu);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(80, 180, 536, 196));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(12);
        label_2->setFont(font1);

        horizontalLayout->addWidget(label_2);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout->addWidget(lineEdit);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setFont(font1);

        horizontalLayout_2->addWidget(label_3);

        lineEdit_2 = new QLineEdit(layoutWidget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout_2->addWidget(lineEdit_2);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font1);

        horizontalLayout_3->addWidget(label_4);

        lineEdit_3 = new QLineEdit(layoutWidget);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        horizontalLayout_3->addWidget(lineEdit_3);


        verticalLayout->addLayout(horizontalLayout_3);


        horizontalLayout_5->addLayout(verticalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font1);

        horizontalLayout_4->addWidget(label_5);

        textEdit = new QTextEdit(layoutWidget);
        textEdit->setObjectName(QStringLiteral("textEdit"));

        horizontalLayout_4->addWidget(textEdit);


        horizontalLayout_5->addLayout(horizontalLayout_4);


        retranslateUi(Yezhuguzhuangbaoxiu);

        QMetaObject::connectSlotsByName(Yezhuguzhuangbaoxiu);
    } // setupUi

    void retranslateUi(QWidget *Yezhuguzhuangbaoxiu)
    {
        Yezhuguzhuangbaoxiu->setWindowTitle(QApplication::translate("Yezhuguzhuangbaoxiu", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("Yezhuguzhuangbaoxiu", "\346\225\205\351\232\234\346\212\245\344\277\256", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Yezhuguzhuangbaoxiu", "\346\212\245\344\277\256", Q_NULLPTR));
        label_2->setText(QApplication::translate("Yezhuguzhuangbaoxiu", "\345\247\223\345\220\215", Q_NULLPTR));
        label_3->setText(QApplication::translate("Yezhuguzhuangbaoxiu", "\347\224\265\350\257\235", Q_NULLPTR));
        label_4->setText(QApplication::translate("Yezhuguzhuangbaoxiu", "\345\234\260\345\235\200", Q_NULLPTR));
        label_5->setText(QApplication::translate("Yezhuguzhuangbaoxiu", "\351\227\256\351\242\230", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Yezhuguzhuangbaoxiu: public Ui_Yezhuguzhuangbaoxiu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YEZHUGUZHUANGBAOXIU_H
