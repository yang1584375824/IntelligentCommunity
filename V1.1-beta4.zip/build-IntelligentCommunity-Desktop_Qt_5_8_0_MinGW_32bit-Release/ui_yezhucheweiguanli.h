/********************************************************************************
** Form generated from reading UI file 'yezhucheweiguanli.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YEZHUCHEWEIGUANLI_H
#define UI_YEZHUCHEWEIGUANLI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Yezhucheweiguanli
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_3;
    QLineEdit *numlineEdit;
    QLabel *label_2;
    QLineEdit *brandlineEdit;
    QLabel *label;
    QLineEdit *colorlineEdit;
    QPushButton *pushButton;
    QTableView *tableView;
    QPushButton *delpushButton;
    QTableView *tableView_2;
    QTableView *tableView_3;
    QLabel *label_4;
    QLabel *label_5;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QLabel *label_6;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer;
    QLineEdit *parklineEdit;
    QSpacerItem *verticalSpacer_2;
    QPushButton *shenpushButton;

    void setupUi(QWidget *Yezhucheweiguanli)
    {
        if (Yezhucheweiguanli->objectName().isEmpty())
            Yezhucheweiguanli->setObjectName(QStringLiteral("Yezhucheweiguanli"));
        Yezhucheweiguanli->resize(635, 592);
        Yezhucheweiguanli->setStyleSheet(QStringLiteral("background-image: url();"));
        horizontalLayoutWidget = new QWidget(Yezhucheweiguanli);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(20, 10, 591, 41));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(horizontalLayoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout->addWidget(label_3);

        numlineEdit = new QLineEdit(horizontalLayoutWidget);
        numlineEdit->setObjectName(QStringLiteral("numlineEdit"));

        horizontalLayout->addWidget(numlineEdit);

        label_2 = new QLabel(horizontalLayoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        brandlineEdit = new QLineEdit(horizontalLayoutWidget);
        brandlineEdit->setObjectName(QStringLiteral("brandlineEdit"));

        horizontalLayout->addWidget(brandlineEdit);

        label = new QLabel(horizontalLayoutWidget);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        colorlineEdit = new QLineEdit(horizontalLayoutWidget);
        colorlineEdit->setObjectName(QStringLiteral("colorlineEdit"));

        horizontalLayout->addWidget(colorlineEdit);

        pushButton = new QPushButton(horizontalLayoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);

        tableView = new QTableView(Yezhucheweiguanli);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(20, 50, 471, 101));
        delpushButton = new QPushButton(Yezhucheweiguanli);
        delpushButton->setObjectName(QStringLiteral("delpushButton"));
        delpushButton->setGeometry(QRect(520, 90, 91, 31));
        tableView_2 = new QTableView(Yezhucheweiguanli);
        tableView_2->setObjectName(QStringLiteral("tableView_2"));
        tableView_2->setGeometry(QRect(20, 450, 601, 101));
        tableView_3 = new QTableView(Yezhucheweiguanli);
        tableView_3->setObjectName(QStringLiteral("tableView_3"));
        tableView_3->setGeometry(QRect(20, 220, 431, 141));
        label_4 = new QLabel(Yezhucheweiguanli);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(190, 170, 91, 31));
        label_5 = new QLabel(Yezhucheweiguanli);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(290, 400, 51, 41));
        verticalLayoutWidget = new QWidget(Yezhucheweiguanli);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(460, 240, 160, 101));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        label_6 = new QLabel(verticalLayoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_2->addWidget(label_6);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        parklineEdit = new QLineEdit(verticalLayoutWidget);
        parklineEdit->setObjectName(QStringLiteral("parklineEdit"));

        verticalLayout->addWidget(parklineEdit);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        shenpushButton = new QPushButton(verticalLayoutWidget);
        shenpushButton->setObjectName(QStringLiteral("shenpushButton"));

        verticalLayout->addWidget(shenpushButton);


        retranslateUi(Yezhucheweiguanli);

        QMetaObject::connectSlotsByName(Yezhucheweiguanli);
    } // setupUi

    void retranslateUi(QWidget *Yezhucheweiguanli)
    {
        Yezhucheweiguanli->setWindowTitle(QApplication::translate("Yezhucheweiguanli", "Form", Q_NULLPTR));
        label_3->setText(QApplication::translate("Yezhucheweiguanli", "\350\275\246\347\211\214\345\217\267", Q_NULLPTR));
        label_2->setText(QApplication::translate("Yezhucheweiguanli", "\350\275\246\350\276\206\345\223\201\347\211\214", Q_NULLPTR));
        label->setText(QApplication::translate("Yezhucheweiguanli", "\350\275\246\350\276\206\351\242\234\350\211\262", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Yezhucheweiguanli", "\346\267\273\345\212\240\350\275\246\350\276\206", Q_NULLPTR));
        delpushButton->setText(QApplication::translate("Yezhucheweiguanli", "\345\210\240\351\231\244\350\275\246\350\276\206\344\277\241\346\201\257", Q_NULLPTR));
        label_4->setText(QApplication::translate("Yezhucheweiguanli", "\345\217\257\347\224\263\350\257\267\350\275\246\344\275\215\344\277\241\346\201\257", Q_NULLPTR));
        label_5->setText(QApplication::translate("Yezhucheweiguanli", "\346\210\221\347\232\204\350\275\246\344\275\215", Q_NULLPTR));
        label_6->setText(QApplication::translate("Yezhucheweiguanli", "\350\275\246\344\275\215\347\274\226\345\217\267", Q_NULLPTR));
        shenpushButton->setText(QApplication::translate("Yezhucheweiguanli", "\347\224\263\350\257\267\350\275\246\344\275\215", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Yezhucheweiguanli: public Ui_Yezhucheweiguanli {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YEZHUCHEWEIGUANLI_H
