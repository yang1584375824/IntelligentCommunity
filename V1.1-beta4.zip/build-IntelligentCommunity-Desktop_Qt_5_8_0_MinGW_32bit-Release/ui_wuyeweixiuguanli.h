/********************************************************************************
** Form generated from reading UI file 'wuyeweixiuguanli.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WUYEWEIXIUGUANLI_H
#define UI_WUYEWEIXIUGUANLI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Wuyeweixiuguanli
{
public:
    QTableView *tableView;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_6;
    QLineEdit *lineEdit_4;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_7;
    QLineEdit *lineEdit_5;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_8;
    QLineEdit *lineEdit_6;
    QTextEdit *textEdit;
    QWidget *layoutWidget6;
    QVBoxLayout *verticalLayout;
    QLabel *label_9;
    QLabel *label_5;

    void setupUi(QWidget *Wuyeweixiuguanli)
    {
        if (Wuyeweixiuguanli->objectName().isEmpty())
            Wuyeweixiuguanli->setObjectName(QStringLiteral("Wuyeweixiuguanli"));
        Wuyeweixiuguanli->resize(700, 600);
        Wuyeweixiuguanli->setStyleSheet(QStringLiteral("background-image: url();"));
        tableView = new QTableView(Wuyeweixiuguanli);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(40, 60, 621, 211));
        label = new QLabel(Wuyeweixiuguanli);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(280, 20, 111, 31));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(16);
        label->setFont(font);
        pushButton = new QPushButton(Wuyeweixiuguanli);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(500, 340, 71, 31));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(14);
        pushButton->setFont(font1);
        pushButton_2 = new QPushButton(Wuyeweixiuguanli);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(550, 510, 71, 31));
        pushButton_2->setFont(font1);
        pushButton_3 = new QPushButton(Wuyeweixiuguanli);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(600, 340, 61, 31));
        pushButton_3->setFont(font1);
        pushButton_4 = new QPushButton(Wuyeweixiuguanli);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(550, 450, 71, 31));
        pushButton_4->setFont(font1);
        layoutWidget = new QWidget(Wuyeweixiuguanli);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(40, 320, 173, 23));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font2;
        font2.setFamily(QStringLiteral("Agency FB"));
        font2.setPointSize(12);
        label_2->setFont(font2);

        horizontalLayout->addWidget(label_2);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout->addWidget(lineEdit);

        layoutWidget1 = new QWidget(Wuyeweixiuguanli);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(260, 320, 205, 23));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font2);

        horizontalLayout_2->addWidget(label_6);

        lineEdit_4 = new QLineEdit(layoutWidget1);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        horizontalLayout_2->addWidget(lineEdit_4);

        layoutWidget2 = new QWidget(Wuyeweixiuguanli);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(40, 370, 173, 23));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setFont(font2);

        horizontalLayout_3->addWidget(label_3);

        lineEdit_2 = new QLineEdit(layoutWidget2);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout_3->addWidget(lineEdit_2);

        layoutWidget3 = new QWidget(Wuyeweixiuguanli);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(260, 370, 205, 23));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget3);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font2);

        horizontalLayout_4->addWidget(label_7);

        lineEdit_5 = new QLineEdit(layoutWidget3);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));

        horizontalLayout_4->addWidget(lineEdit_5);

        layoutWidget4 = new QWidget(Wuyeweixiuguanli);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(40, 420, 173, 23));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(layoutWidget4);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font2);

        horizontalLayout_5->addWidget(label_4);

        lineEdit_3 = new QLineEdit(layoutWidget4);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        horizontalLayout_5->addWidget(lineEdit_3);

        layoutWidget5 = new QWidget(Wuyeweixiuguanli);
        layoutWidget5->setObjectName(QStringLiteral("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(260, 420, 205, 23));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(layoutWidget5);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setFont(font2);

        horizontalLayout_6->addWidget(label_8);

        lineEdit_6 = new QLineEdit(layoutWidget5);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));

        horizontalLayout_6->addWidget(lineEdit_6);

        textEdit = new QTextEdit(Wuyeweixiuguanli);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(89, 461, 381, 109));
        layoutWidget6 = new QWidget(Wuyeweixiuguanli);
        layoutWidget6->setObjectName(QStringLiteral("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(41, 461, 42, 49));
        verticalLayout = new QVBoxLayout(layoutWidget6);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget6);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setFont(font2);

        verticalLayout->addWidget(label_9);

        label_5 = new QLabel(layoutWidget6);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font2);

        verticalLayout->addWidget(label_5);


        retranslateUi(Wuyeweixiuguanli);

        QMetaObject::connectSlotsByName(Wuyeweixiuguanli);
    } // setupUi

    void retranslateUi(QWidget *Wuyeweixiuguanli)
    {
        Wuyeweixiuguanli->setWindowTitle(QApplication::translate("Wuyeweixiuguanli", "staff_Widget", Q_NULLPTR));
        label->setText(QApplication::translate("Wuyeweixiuguanli", "\347\273\264\344\277\256\347\256\241\347\220\206\357\274\232", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Wuyeweixiuguanli", "\346\230\276\347\244\272", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Wuyeweixiuguanli", "\344\277\256\346\224\271", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Wuyeweixiuguanli", "\345\210\240\351\231\244", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("Wuyeweixiuguanli", "\346\237\245\350\257\242", Q_NULLPTR));
        label_2->setText(QApplication::translate("Wuyeweixiuguanli", "\345\247\223\345\220\215", Q_NULLPTR));
        label_6->setText(QApplication::translate("Wuyeweixiuguanli", "\347\273\264\344\277\256\346\203\205\345\206\265", Q_NULLPTR));
        label_3->setText(QApplication::translate("Wuyeweixiuguanli", "\347\224\265\350\257\235", Q_NULLPTR));
        label_7->setText(QApplication::translate("Wuyeweixiuguanli", "\347\273\264\344\277\256\350\277\233\345\272\246", Q_NULLPTR));
        label_4->setText(QApplication::translate("Wuyeweixiuguanli", "\344\275\217\345\235\200", Q_NULLPTR));
        label_8->setText(QApplication::translate("Wuyeweixiuguanli", "\347\273\264\344\277\256\350\257\204\344\273\267", Q_NULLPTR));
        label_9->setText(QApplication::translate("Wuyeweixiuguanli", "\351\227\256\351\242\230", Q_NULLPTR));
        label_5->setText(QApplication::translate("Wuyeweixiuguanli", "\346\217\217\350\277\260", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Wuyeweixiuguanli: public Ui_Wuyeweixiuguanli {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WUYEWEIXIUGUANLI_H
