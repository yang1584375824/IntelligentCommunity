/********************************************************************************
** Form generated from reading UI file 'yezhujiaofeichaxun.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YEZHUJIAOFEICHAXUN_H
#define UI_YEZHUJIAOFEICHAXUN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Yezhujiaofeichaxun
{
public:
    QLabel *label_4;
    QTableView *tableView;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QLabel *label_3;
    QLabel *label_5;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_3;

    void setupUi(QWidget *Yezhujiaofeichaxun)
    {
        if (Yezhujiaofeichaxun->objectName().isEmpty())
            Yezhujiaofeichaxun->setObjectName(QStringLiteral("Yezhujiaofeichaxun"));
        Yezhujiaofeichaxun->resize(700, 600);
        Yezhujiaofeichaxun->setStyleSheet(QStringLiteral("background-image: url();"));
        label_4 = new QLabel(Yezhujiaofeichaxun);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(260, 10, 161, 91));
        tableView = new QTableView(Yezhujiaofeichaxun);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(70, 270, 541, 211));
        horizontalLayoutWidget_2 = new QWidget(Yezhujiaofeichaxun);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(70, 140, 521, 91));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QStringLiteral("label"));
        QFont font;
        font.setFamily(QStringLiteral("Agency FB"));
        font.setPointSize(11);
        label->setFont(font);

        horizontalLayout_2->addWidget(label);

        lineEdit = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout_2->addWidget(lineEdit);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(horizontalLayoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setFont(font);

        horizontalLayout->addWidget(label_2);

        lineEdit_2 = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout->addWidget(lineEdit_2);


        horizontalLayout_2->addLayout(horizontalLayout);

        label_3 = new QLabel(Yezhujiaofeichaxun);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(70, 240, 72, 15));
        label_5 = new QLabel(Yezhujiaofeichaxun);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(60, 100, 111, 41));
        horizontalLayoutWidget = new QWidget(Yezhujiaofeichaxun);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(410, 480, 195, 80));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(horizontalLayoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        QFont font1;
        font1.setFamily(QStringLiteral("Agency FB"));
        font1.setPointSize(12);
        pushButton->setFont(font1);

        horizontalLayout_3->addWidget(pushButton);

        pushButton_2 = new QPushButton(horizontalLayoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setFont(font1);

        horizontalLayout_3->addWidget(pushButton_2);

        lineEdit_3 = new QLineEdit(Yezhujiaofeichaxun);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(170, 110, 113, 21));

        retranslateUi(Yezhujiaofeichaxun);

        QMetaObject::connectSlotsByName(Yezhujiaofeichaxun);
    } // setupUi

    void retranslateUi(QWidget *Yezhujiaofeichaxun)
    {
        Yezhujiaofeichaxun->setWindowTitle(QApplication::translate("Yezhujiaofeichaxun", "Widget", Q_NULLPTR));
        label_4->setText(QApplication::translate("Yezhujiaofeichaxun", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; color:#0055ff;\">\347\274\264\350\264\271\346\237\245\350\257\242</span></p></body></html>", Q_NULLPTR));
        label->setText(QApplication::translate("Yezhujiaofeichaxun", "\347\274\264\350\264\271\347\261\273\345\236\213", Q_NULLPTR));
        label_2->setText(QApplication::translate("Yezhujiaofeichaxun", "\346\227\266\351\227\264", Q_NULLPTR));
        label_3->setText(QApplication::translate("Yezhujiaofeichaxun", "\346\237\245\350\257\242\347\273\223\346\236\234", Q_NULLPTR));
        label_5->setText(QApplication::translate("Yezhujiaofeichaxun", "<html><head/><body><p align=\"center\"><span style=\" font-size:11pt; color:#0055ff;\">\344\272\262\347\210\261\347\232\204\344\270\232\344\270\273</span></p></body></html>", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Yezhujiaofeichaxun", "\346\237\245\350\257\242", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Yezhujiaofeichaxun", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Yezhujiaofeichaxun: public Ui_Yezhujiaofeichaxun {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YEZHUJIAOFEICHAXUN_H
