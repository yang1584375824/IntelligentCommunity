#include "guanliyuanqingjiashenpi.h"
#include "ui_guanliyuanqingjiashenpi.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

Guanliyuanqingjiashenpi::Guanliyuanqingjiashenpi(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Guanliyuanqingjiashenpi)
{
    ui->setupUi(this);
    //建立并打开数据库
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("qingjia.db");
    if (!db.open()) {
        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
            QObject::tr("不能建立链接n.\n"
                        "This example needs SQLite support. Please read "
                        "the Qt SQL driver documentation for information how "
                        "to build it.\n\n"
                        "Click Cancel to exit."), QMessageBox::Cancel);
    }else{
        qDebug()<<"数据库打开成功！ "<<endl;
      //  ui->label_data->setText(tr("数据库打开成功"));
    }
}

Guanliyuanqingjiashenpi::~Guanliyuanqingjiashenpi()
{
    delete ui;
}

void Guanliyuanqingjiashenpi::on_pushButton_clicked()
{
    QString name[100];//用来存储从数据库中找出来的信息
    QString date[100];
    QString id[100];
    QString date2[100];
    QString shenpi[100];
    QString shenpi2[100];
    int i = 0;
    QSqlQuery query;
    query.exec("select * from book");//查询所有的信息
    while(query.next())
    {
        name[i] = query.value(0).toString();
        date[i] = query.value(1).toString();
        id[i] = query.value(2).toString();
        date2[i] = query.value(3).toString();
        shenpi[i] = query.value(4).toString();\
        shenpi2[i] = query.value(5).toString();
        i++;
    }
    ui->textEdit->clear();
    int j = 0;
    for(j = 0; j < i; j++)//将这些信息都显示在下方的文本编辑框中
    {
        QString str = QString("姓名：%1 请假时间：%2 原因：%3 结束时间：%4 审批：%5 审批：%6").arg(name[j]).arg(date[j]).arg(id[j]).arg(date2[j]).arg(shenpi[j]).arg(shenpi2[j]);
        ui->textEdit->append(str);
    }
}

void Guanliyuanqingjiashenpi::on_pushButton_2_clicked()
{

    QString updatename = ui->lineEdit->text();
    //QString updatedate = ui->lineEdit_2->text();
   // QString updateid = ui->lineEdit_3->text();
    // QString updatedate2 = ui->lineEdit_4->text();
      QString updateshenpi = ui->lineEdit_5->text();
      QString updateshenpi2 = ui->lineEdit_6->text();
      if(updatename == NULL )
          {
               QMessageBox::information(NULL,"fail"," 请输入需要修改的人的名字、请假日期、原因、结束时间、审批、审批2");
          }
      else
      {
      QString temp = QString("select * from book where name = '%1'").arg(updatename);

      QSqlQuery query;
      query.exec(temp);// 查询信息
      QString c;
      while (query.next())
      {
          c = query.value(1).toString();
      }
      if(c == NULL)
      {
          QString b = QString("没有名叫%1的人，修改失败").arg(updatename);
          QMessageBox::information(NULL,"fail",b);
          ui->lineEdit->clear();
          //ui->lineEdit_2->clear();
          //ui->lineEdit_3->clear();
         // ui->lineEdit_4->clear();
          ui->lineEdit_5->clear();
          ui->lineEdit_6->clear();
      }
      else
      {

         //QString temp = QString("update book set date = '%1' , id = '%2', date2 = '%3', shenpi = '%4', shenpi2 = '%5' where name = '%6'").arg(updatedate).arg(updateid).arg(updatedate2).arg(updateshenpi).arg(updateshenpi2).arg(updatename);
        QString temp = QString("update book set shenpi = '%1', shenpi2 = '%2' where name = '%3'").arg(updateshenpi).arg(updateshenpi2).arg(updatename);
         QSqlQuery query;
         query.exec(temp);
         QMessageBox::information(NULL,"Success"," 信息修改成功!!");
            ui->lineEdit->clear();
           // ui->lineEdit_2->clear();
            //ui->lineEdit_3->clear();
           // ui->lineEdit_4->clear();
            ui->lineEdit_5->clear();
              ui->lineEdit_6->clear();
        }
}
}

void Guanliyuanqingjiashenpi::on_pushButton_3_clicked()
{
    QString updatename = ui->lineEdit->text();
    //QString updatedate = ui->lineEdit_2->text();
   // QString updateid = ui->lineEdit_3->text();
    // QString updatedate2 = ui->lineEdit_4->text();
      QString updateshenpi = ui->lineEdit_5->text();
      QString updateshenpi2 = ui->lineEdit_6->text();
      if(updatename == NULL )
          {
               QMessageBox::information(NULL,"fail"," 请输入需要修改的人的名字、请假日期、原因、结束时间、审批、审批2");
          }
      else
      {
      QString temp = QString("select * from book where name = '%1'").arg(updatename);

      QSqlQuery query;
      query.exec(temp);// 查询信息
      QString c;
      while (query.next())
      {
          c = query.value(1).toString();
      }
      if(c == NULL)
      {
          QString b = QString("没有名叫%1的人，修改失败").arg(updatename);
          QMessageBox::information(NULL,"fail",b);
          ui->lineEdit->clear();
          //ui->lineEdit_2->clear();
          //ui->lineEdit_3->clear();
         // ui->lineEdit_4->clear();
          ui->lineEdit_5->clear();
          ui->lineEdit_6->clear();
      }
      else
      {

         //QString temp = QString("update book set date = '%1' , id = '%2', date2 = '%3', shenpi = '%4', shenpi2 = '%5' where name = '%6'").arg(updatedate).arg(updateid).arg(updatedate2).arg(updateshenpi).arg(updateshenpi2).arg(updatename);
        QString temp = QString("update book set shenpi = '%1', shenpi2 = '%2' where name = '%3'").arg(updateshenpi).arg(updateshenpi2).arg(updatename);
         QSqlQuery query;
         query.exec(temp);
         QMessageBox::information(NULL,"Success"," 信息修改成功!!");
            ui->lineEdit->clear();
           // ui->lineEdit_2->clear();
            //ui->lineEdit_3->clear();
           // ui->lineEdit_4->clear();
             ui->lineEdit_5->clear();
              ui->lineEdit_6->clear();
        }
}
}
