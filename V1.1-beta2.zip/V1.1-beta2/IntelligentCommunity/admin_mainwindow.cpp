#include "admin_mainwindow.h"
#include "ui_admin_mainwindow.h"
#include "guanliyuanrenshiguanli.h"
#include "ui_guanliyuanrenshiguanli.h"
#include "guanliyuanyueduchuqin.h"
#include "ui_guanliyuanyueduchuqin.h"
#include "guanliyuanqingjiashenpi.h"
#include "ui_guanliyuanqingjiashenpi.h"
extern int yonghuming;

admin_MainWindow::admin_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::admin_MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("管理员管理面板");
    this->setWindowIcon(QIcon(":/logo.png"));
    Guanliyuanrenshiguanli *guanliyuanrenshiguanli = new Guanliyuanrenshiguanli;
    this->setCentralWidget(guanliyuanrenshiguanli);

}

admin_MainWindow::~admin_MainWindow()
{
    delete ui;
}

void admin_MainWindow::on_action_triggered()//人事管理
{
    Guanliyuanrenshiguanli *guanliyuanrenshiguanli = new Guanliyuanrenshiguanli;
    this->setCentralWidget(guanliyuanrenshiguanli);
}

void admin_MainWindow::on_action_2_triggered()//月度出勤
{
    Guanliyuanyueduchuqin *chuqin =new Guanliyuanyueduchuqin;
    setCentralWidget(chuqin);
}

void admin_MainWindow::on_action_3_triggered()//请假审批
{
    Guanliyuanqingjiashenpi *pi = new Guanliyuanqingjiashenpi;
    setCentralWidget(pi);
}
