#include "wuyeqingxiaojia.h"
#include "ui_wuyeqingxiaojia.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

Wuyeqingxiaojia::Wuyeqingxiaojia(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyeqingxiaojia)
{
    ui->setupUi(this);
    //建立并打开数据库
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("qingjia.db");
    if (!db.open()) {
        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
            QObject::tr("不能建立链接n.\n"
                        "This example needs SQLite support. Please read "
                        "the Qt SQL driver documentation for information how "
                        "to build it.\n\n"
                        "Click Cancel to exit."), QMessageBox::Cancel);
    }else{
        qDebug()<<"数据库打开成功！ "<<endl;
      //  ui->label_data->setText(tr("数据库打开成功"));
    }
}

Wuyeqingxiaojia::~Wuyeqingxiaojia()
{
    delete ui;
}
void Wuyeqingxiaojia::on_pushButton_clicked()
{
    QString name = ui->lineEdit->text();
    QString date = ui->lineEdit_2->text();
    QString id = ui->lineEdit_3->text();
    QString date2 = ui->lineEdit_4->text();
    QString str = QString("insert into book (name,date,id,date2) values('%1','%2','%3','%4') ").arg(name).arg(date).arg(id).arg(date2);
    QSqlQuery query;

        if(!query.exec(str))
        {
             qDebug()<<"there is not a table of book in mysql!"<<query.lastError();
        }
        else
        {
            QMessageBox::information(NULL,"Success"," 数据写入成功！！");
        }
}

void Wuyeqingxiaojia::on_pushButton_3_clicked()
{
    QString updatename = ui->lineEdit->text();
    //QString updateshangban = ui->lineEdit_2->text();
    QString updatedate2 = ui->lineEdit_4->text();
      if(updatename == NULL )
          {
               QMessageBox::information(NULL,"fail"," 请输入需要修改的人的名字、结束时间");
          }
      else
      {
      QString temp = QString("select * from book where name = '%1'").arg(updatename);

      QSqlQuery query;
      query.exec(temp);// 查询信息
      QString c;
      while (query.next())
      {
          c = query.value(1).toString();
      }
      if(c == NULL)
      {
          QString b = QString("没有名叫%1的人，修改失败").arg(updatename);
          QMessageBox::information(NULL,"fail",b);
          ui->lineEdit->clear();
          //ui->lineEdit_2->clear();
          ui->lineEdit_4->clear();
      }
      else
      {

         QString temp = QString("update book set date2 = '%1' where name = '%2'").arg(updatedate2).arg(updatename);
         QSqlQuery query;
         query.exec(temp);
         QMessageBox::information(NULL,"Success"," 信息修改成功!!");
            ui->lineEdit->clear();
            //ui->lineEdit_2->clear();
            ui->lineEdit_4->clear();
        }
}
}
