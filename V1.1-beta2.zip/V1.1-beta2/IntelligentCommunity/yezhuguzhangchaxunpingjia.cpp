#include "yezhuguzhangchaxunpingjia.h"
#include "ui_yezhuguzhangchaxunpingjia.h"

Yezhuguzhangchaxunpingjia::Yezhuguzhangchaxunpingjia(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Yezhuguzhangchaxunpingjia)
{
    ui->setupUi(this);
    /**连接数据库**/
        db=QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("wuye.db");
        if(!db.open()){
            QMessageBox::information(NULL,"提示","数据库连接失败",QMessageBox::Ok);
        }else{
            QMessageBox::information(NULL,"提示","数据库连接成功",QMessageBox::Ok);
        }
}

Yezhuguzhangchaxunpingjia::~Yezhuguzhangchaxunpingjia()
{
    delete ui;
}

void Yezhuguzhangchaxunpingjia::on_pushButton_4_clicked()
{
    QString searchname = ui->lineEdit->text();
    if(searchname==NULL)
    {
         QMessageBox::information(NULL,"提示","请输入查询姓名",QMessageBox::Ok);
    }
    else
    {
        QString str=QString("select * from weixiu where name = '%1'").arg(searchname);
        QSqlQuery query;
        if(!query.exec(str))
        {
            qDebug()<<"there is not a table of weixiu in mysql"<<query.lastError();
        }
        QString tel,add,pro,bao,jin,pin;
        while(query.next())
        {
            tel=query.value(2).toString();
            add=query.value(3).toString();
            pro=query.value(4).toString();
            bao=query.value(5).toString();
            jin=query.value(6).toString();
            pin=query.value(7).toString();

            ui->lineEdit_2->setText(tel);
            ui->lineEdit_3->setText(add);
            ui->textEdit->setText(pro);
            ui->lineEdit_4->setText(bao);
            ui->lineEdit_5->setText(jin);
            ui->lineEdit_6->setText(pin);
            ui->lineEdit_4->setFocusPolicy(Qt::NoFocus);
            ui->lineEdit_5->setFocusPolicy(Qt::NoFocus);
        }

    }
}

void Yezhuguzhangchaxunpingjia::on_pushButton_2_clicked()
{
    QString eval = ui->lineEdit_6->text();
    QString searchname = ui ->lineEdit->text();
    QString temp = QString("update weixiu set eval = '%1' where name = '%2'").arg(eval).arg(searchname);
    QSqlQuery query;
    query.exec(temp);
    QMessageBox::information(NULL,"Success"," 信息修改成功!!");
}
