#include "wuyecheweichuzu.h"
#include "ui_wuyecheweichuzu.h"
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDebug>

Wuyecheweichuzu::Wuyecheweichuzu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyecheweichuzu)
{
    ui->setupUi(this);
}

Wuyecheweichuzu::~Wuyecheweichuzu()
{
    delete ui;
}

void Wuyecheweichuzu::on_selectpushButton_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("wuye_value.db");
    if(!db.open()){
        QMessageBox::critical(0,"Cannot open database","Unable to open",QMessageBox::Cancel);
    }

    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString sql = QString("select number,addr,sellout,user_id from park where sellout='%1'").arg("否");
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"车位编号");
    model->setHeaderData(1,Qt::Horizontal,"车位地址");
    model->setHeaderData(2,Qt::Horizontal,"是否出售");
    model->setHeaderData(3,Qt::Horizontal,"购买者");
    ui->tableView->setModel(model);
    db.close();
}

void Wuyecheweichuzu::on_yespushButton_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("wuye_value.db");
    if(!db.open()){
        QMessageBox::critical(0,"Cannot open database","Unable to open",QMessageBox::Cancel);
    }

    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString IDcard = ui->IDlineEdit->text();
    QString number = ui->numlineEdit->text();
    QString name = ui->namelineEdit->text();
    QSqlQuery query;
    QString sql = QString("select id from user where name='%1' and IDcard='%2'").arg(name).arg(IDcard);
    query.exec(sql);
    if(query.next()){
        int user_id = query.value(0).toInt();
        sql = QString("update park set sellout='%1',user_id='%2'where number='%3'").arg("是").arg(user_id).arg(number);
        query.exec(sql);
        sql = QString("select * from (select p.number,p.addr,p.sellout,u.name,u.IDcard,u.phone from park as p inner join user as u on p.user_id=u.id) where IDcard='%1';").arg(IDcard);
        model->setQuery(sql);
        qDebug()<<model->rowCount();
        model->setHeaderData(0,Qt::Horizontal,"车位编号");
        model->setHeaderData(1,Qt::Horizontal,"车位地址");
        model->setHeaderData(2,Qt::Horizontal,"是否出售");
        model->setHeaderData(3,Qt::Horizontal,"购买者姓名");
        model->setHeaderData(4,Qt::Horizontal,"身份证号");
        model->setHeaderData(5,Qt::Horizontal,"联系方式");
        ui->tableView->setModel(model);
        ui->IDlineEdit->clear();
        ui->numlineEdit->clear();
        ui->namelineEdit->clear();
    }
    db.close();
}
