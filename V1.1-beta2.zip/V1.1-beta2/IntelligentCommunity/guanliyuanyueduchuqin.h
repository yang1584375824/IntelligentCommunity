#ifndef CHUQIN_H
#define CHUQIN_H

#include <QWidget>

namespace Ui {
class Guanliyuanyueduchuqin;
}

class Guanliyuanyueduchuqin : public QWidget
{
    Q_OBJECT

public:
    explicit Guanliyuanyueduchuqin(QWidget *parent = 0);
    ~Guanliyuanyueduchuqin();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Guanliyuanyueduchuqin *ui;
};

#endif // CHUQIN_H
