/********************************************************************************
** Form generated from reading UI file 'chuqin_copy.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHUQIN_COPY_H
#define UI_CHUQIN_COPY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_chuqin
{
public:
    QTextEdit *textEdit;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QWidget *chuqin)
    {
        if (chuqin->objectName().isEmpty())
            chuqin->setObjectName(QStringLiteral("chuqin"));
        chuqin->resize(704, 624);
        textEdit = new QTextEdit(chuqin);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(80, 120, 541, 381));
        pushButton_2 = new QPushButton(chuqin);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(370, 520, 93, 28));
        pushButton = new QPushButton(chuqin);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(200, 520, 93, 28));
        label = new QLabel(chuqin);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(230, 40, 181, 51));

        retranslateUi(chuqin);
        QObject::connect(pushButton_2, SIGNAL(clicked()), chuqin, SLOT(close()));

        QMetaObject::connectSlotsByName(chuqin);
    } // setupUi

    void retranslateUi(QWidget *chuqin)
    {
        chuqin->setWindowTitle(QApplication::translate("chuqin", "Form", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("chuqin", "\351\200\200\345\207\272", Q_NULLPTR));
        pushButton->setText(QApplication::translate("chuqin", "\350\257\246\347\273\206", Q_NULLPTR));
        label->setText(QApplication::translate("chuqin", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600;\">\346\234\210\345\272\246\345\207\272\345\213\244\346\203\205\345\206\265</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class chuqin: public Ui_chuqin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHUQIN_COPY_H
