#include "wuyejiagewihu.h"
#include "ui_wuyejiagewihu.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

Wuyejiagewihu::Wuyejiagewihu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyejiagewihu)
{
    ui->setupUi(this);
    //建立并打开数据库
//        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
//        db.setDatabaseName("jiaofeixinxi.db");
//    if (!db.open()) {
//        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
//            QObject::tr("不能建立链接n.\n"
//                        "This example needs SQLite support. Please read "
//                        "the Qt SQL driver documentation for information how "
//                        "to build it.\n\n"
//                        "Click Cancel to exit."), QMessageBox::Cancel);
//    }else{
//        qDebug()<<"数据库打开成功！ "<<endl;
//      //  ui->label_data->setText(tr("数据库打开成功"));
//    }
}

Wuyejiagewihu::~Wuyejiagewihu()
{
    delete ui;
}
void Wuyejiagewihu::on_pushButton_clicked()
{
    QString userid = ui->lineEdit_4->text();
    QString wuye = ui->lineEdit_5->text();
    QString chewei = ui->lineEdit_6->text();
    QString weixiu = ui->lineEdit_7->text();
    QString date = ui->lineEdit->text();
    QString name = ui->lineEdit_2->text();
    if(userid == NULL) //插入信息的时候需要输入完整的信息
    {
        QMessageBox::information(NULL,"fail "," 信息写入失败！！ 请输入完整的信息");
    }
    else
    {
       QString str = QString("insert into typer (userid,type,number)values ('%1','%2','%3') ").arg(userid).arg("物业费").arg(wuye);
       QString str1 = QString("insert into typer (userid,type,number)values ('%1','%2','%3') ").arg(userid).arg("车位费").arg(chewei);
       QString str2 = QString("insert into typer (userid,type,number)values ('%1','%2','%3') ").arg(userid).arg("维修费").arg(weixiu);
       QString str3 = QString("insert into payment (id,name,type,date,state) values('%1','%2','%3','%4','%5') ").arg(userid).arg(name).arg("物业费").arg(date).arg("否");
       QString str4 = QString("insert into payment (id,name,type,date,state) values('%1','%2','%3','%4','%5') ").arg(userid).arg(name).arg("车位费").arg(date).arg("否");
       QString str5 = QString("insert into payment (id,name,type,date,state) values('%1','%2','%3','%4','%5') ").arg(userid).arg(name).arg("维修费").arg(date).arg("否");
        QSqlQuery query;
        QSqlQuery query1;
        QSqlQuery query2;
        QSqlQuery query3;
        QSqlQuery query4;
        QSqlQuery query5;
        query.exec(str); //执行插入操作
        query1.exec(str1);
        query2.exec(str2);
        query3.exec(str3);
        query4.exec(str4);
        query5.exec(str5);
        ui->lineEdit_4->clear();
        ui->lineEdit_5->clear();
        ui->lineEdit_6->clear();
        ui->lineEdit->clear();
        ui->lineEdit_2->clear();
        ui->lineEdit_7->clear();
        QMessageBox::information(NULL,"Success"," 信息写入成功！！");
    }
}
