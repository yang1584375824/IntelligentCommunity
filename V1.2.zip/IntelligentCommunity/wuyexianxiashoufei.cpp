#include "wuyexianxiashoufei.h"
#include "ui_wuyexianxiashoufei.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>
#include <QWidget>
extern int yonghuming;
wuyexianxiashoufei::wuyexianxiashoufei(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::wuyexianxiashoufei)
{
    ui->setupUi(this);
}

wuyexianxiashoufei::~wuyexianxiashoufei()
{
    delete ui;
}
void wuyexianxiashoufei::on_pushButton_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString id = ui->lineEdit_4->text();
    QString sql = QString("select payment.*,typer.number from payment inner join typer on payment.id=typer.userid and payment.type=typer.type where id=%1 and state = '%2'").arg(id).arg("否");
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);


}

void wuyexianxiashoufei::on_pushButton_2_clicked()
{
    QString id = ui->lineEdit_4->text();
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString type = ui->lineEdit_5->text();
    QString date = ui->lineEdit_6->text();
    QString sql = QString("update payment set state = '%1' where id = %2 and type = '%3' and date = '%4'").arg("是").arg(id).arg(type).arg(date);
    model->setQuery(sql);
    ui->lineEdit_4->clear();
    ui->lineEdit_5->clear();
    ui->lineEdit_6->clear();
    QMessageBox::information(NULL,"Success"," 缴费成功！！");
}
