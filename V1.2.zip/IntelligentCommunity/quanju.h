#ifndef QUANJU_H
#define QUANJU_H

extern int yonghuming;
int yonghuming = 0;

#endif // QUANJU_H
