#include "wuyeyueduchuqin.h"
#include "ui_wuyeyueduchuqin.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>
#include <QSqlTableModel>

extern int yonghuming;

Wuyeyueduchuqin::Wuyeyueduchuqin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyeyueduchuqin)
{
    ui->setupUi(this);

}

Wuyeyueduchuqin::~Wuyeyueduchuqin()
{
    delete ui;
}



void Wuyeyueduchuqin::on_pushButton1_clicked()
{
            QString str=QString("select * from usrlist where id = '%1'").arg(yonghuming);
            QSqlQuery query;
            query.exec(str);
            QString namel;
            while(query.next())
            {
                namel=query.value(5).toString();
            }
            QSqlTableModel *model = new QSqlTableModel(this);
            model->setTable("chuqin");
            model->setFilter(QObject::tr("name= '%1'").arg(namel));
            model->select();
            model->setEditStrategy(QSqlTableModel::OnManualSubmit);
            ui->tableView->setModel(model);



}
