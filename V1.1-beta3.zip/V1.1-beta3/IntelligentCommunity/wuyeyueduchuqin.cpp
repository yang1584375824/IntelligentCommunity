#include "wuyeyueduchuqin.h"
#include "ui_wuyeyueduchuqin.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

extern int yonghuming;

Wuyeyueduchuqin::Wuyeyueduchuqin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyeyueduchuqin)
{
    ui->setupUi(this);
    //建立并打开数据库
//        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
//        db.setDatabaseName("shangban.db");
//    if (!db.open()) {
//        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
//            QObject::tr("不能建立链接n.\n"
//                        "This example needs SQLite support. Please read "
//                        "the Qt SQL driver documentation for information how "
//                        "to build it.\n\n"
//                        "Click Cancel to exit."), QMessageBox::Cancel);
//    }else{
//        qDebug()<<"数据库打开成功！ "<<endl;
//      //  ui->label_data->setText(tr("数据库打开成功"));
//    }
}

Wuyeyueduchuqin::~Wuyeyueduchuqin()
{
    delete ui;
}



void Wuyeyueduchuqin::on_pushButton1_clicked()
{
    QString name[100];//用来存储从数据库中找出来的信息
    QString shangban[100];
    QString xiaban[100];
    QString date[100];
    int i = 0;
    QSqlQuery query;
    query.exec("select * from book");//查询所有的信息
    while(query.next())
    {
        name[i] = query.value(0).toString();
        shangban[i] = query.value(1).toString();
        xiaban[i] = query.value(2).toString();
        date[i] = query.value(3).toString();
        i++;
    }
    ui->textEdit->clear();
    int j = 0;
    for(j = 0; j < i; j++)//将这些信息都显示在下方的文本编辑框中
    {
        QString str = QString("姓名：%1 上班时间：%2 下班时间：%3 日期：%4").arg(name[j]).arg(shangban[j]).arg(xiaban[j]).arg(date[j]);
        ui->textEdit->append(str);
    }
}
