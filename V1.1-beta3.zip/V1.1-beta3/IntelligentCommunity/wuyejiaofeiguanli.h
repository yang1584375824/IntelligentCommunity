#ifndef WUYEJIAOFEIGUANLI_H
#define WUYEJIAOFEIGUANLI_H

#include <QWidget>

namespace Ui {
class Wuyejiaofeiguanli;
}

class Wuyejiaofeiguanli : public QWidget
{
    Q_OBJECT

public:
    explicit Wuyejiaofeiguanli(QWidget *parent = 0);
    ~Wuyejiaofeiguanli();
private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Wuyejiaofeiguanli *ui;
};

#endif // WUYEJIAOFEIGUANLI_H
