#include "guanliyuanchushihua.h"
#include "ui_guanliyuanchushihua.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

extern int yonghuming;

guanliyuanchushihua::guanliyuanchushihua(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::guanliyuanchushihua)
{
    ui->setupUi(this);
    //建立并打开数据库
//        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
//        db.setDatabaseName("yezhu.db");
//    if (!db.open()) {
//        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
//            QObject::tr("不能建立链接n.\n"
//                        "This example needs SQLite support. Please read "
//                        "the Qt SQL driver documentation for information how "
//                        "to build it.\n\n"
//                        "Click Cancel to exit."), QMessageBox::Cancel);
//    }else{
//        qDebug()<<"数据库打开成功！ "<<endl;
//      //  ui->label_data->setText(tr("数据库打开成功"));
//    }
}

guanliyuanchushihua::~guanliyuanchushihua()
{
    delete ui;
}

void guanliyuanchushihua::on_pushButton_clicked()
{



        //从数据库中查询是否有这个人
        QSqlQuery query;
        QString temp =  QString("select * from user");
        query.exec(temp);




            QString str =  QString("delete from user where mark != 0");
            query.exec(str);//删除信息


            QMessageBox::information(NULL,"Success"," 信息删除成功！！");

}

