#include "guanliyuanrenshiguanli.h"
#include "ui_guanliyuanrenshiguanli.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

extern int yonghuming;

Guanliyuanrenshiguanli::Guanliyuanrenshiguanli(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //建立并打开数据库
//        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
//        db.setDatabaseName("ic.db");
//    if (!db.open()) {
//        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
//            QObject::tr("不能建立链接n.\n"
//                        "This example needs SQLite support. Please read "
//                        "the Qt SQL driver documentation for information how "
//                        "to build it.\n\n"
//                        "Click Cancel to exit."), QMessageBox::Cancel);
//    }else{
//        qDebug()<<"数据库打开成功！ "<<endl;
//      //  ui->label_data->setText(tr("数据库打开成功"));
//    }
}


Guanliyuanrenshiguanli::~Guanliyuanrenshiguanli()
{
    delete ui;
}


void Guanliyuanrenshiguanli::on_pushButton_clicked()
{
    QString searchid = ui->lineEdit_6->text();

    if(searchid == NULL)
    {
         QMessageBox::information(NULL,"fail"," 请输入需要查询的管理员姓名！");
    }
    else
    {
        QString str = QString("select * from usrlist where id = '%1'").arg(searchid);
        QSqlQuery query;
        query.exec(str);
         QString id,tel,IDcard,pwd,mark;
         while (query.next())
         {
             id = query.value(0).toString();
             tel = query.value(1).toString();
             IDcard =query.value(2).toString();
             pwd =  query.value(3).toString();
             mark = query.value(4).toString();
           }

        if(id == NULL)
        {

             ui->lineEdit->clear();
             ui->lineEdit_2->clear();
             ui->lineEdit_3->clear();
             ui->lineEdit_4->clear();
             ui->lineEdit_5->clear();
             ui->lineEdit_6->clear();
             QString a = QString("没有叫%1的人，请重新输入人名").arg(searchid);
              QMessageBox::information(NULL,"fail",a);
        }

    else
        {

            qDebug()<<"id"<<tel<<IDcard<<pwd<<mark;

            ui->lineEdit->setText(id);
            ui->lineEdit_2->setText(tel);
            ui->lineEdit_3->setText(IDcard);
            ui->lineEdit_4->setText(pwd);
            ui->lineEdit_5->setText(mark);
            ui->lineEdit_6->clear();
}
    }
}

void Guanliyuanrenshiguanli::on_pushButton_2_clicked()
{
    QString updateid = ui->lineEdit->text();
    QString updatetel = ui->lineEdit_2->text();
    QString updateIDcard = ui->lineEdit_3->text();
     QString updatepwd = ui->lineEdit_4->text();
      QString updatemark = ui->lineEdit_5->text();
      if(updateid == NULL )
          {
               QMessageBox::information(NULL,"fail"," 请输入需要修改的人的信息");
          }
      else
      {
      QString temp = QString("select * from usrlist where id = '%1'").arg(updateid);

      QSqlQuery query;
      query.exec(temp);// 查询信息
      QString c;
      while (query.next())
      {
          c = query.value(1).toString();
      }
      if(c == NULL)
      {
          QString b = QString("没有名叫%1的人，修改失败").arg(updateid);
          QMessageBox::information(NULL,"fail",b);
          ui->lineEdit->clear();
          ui->lineEdit_2->clear();
          ui->lineEdit_3->clear();
          ui->lineEdit_4->clear();
          ui->lineEdit_5->clear();
      }
      else
      {

         QString temp = QString("update usrlist set tel = '%1' , IDcard = '%2', pwd = '%3', mark = '%4' where id = '%5'").arg(updatetel).arg(updateIDcard).arg(updatepwd).arg(updatemark).arg(updateid);
         QSqlQuery query;
         query.exec(temp);
         QMessageBox::information(NULL,"Success"," 信息修改成功!!");
            ui->lineEdit->clear();
            ui->lineEdit_2->clear();
            ui->lineEdit_3->clear();
            ui->lineEdit_4->clear();
            ui->lineEdit_5->clear();
        }
}
}

void Guanliyuanrenshiguanli::on_pushButton_3_clicked()
{
    QString userid = ui->lineEdit->text();
    QString tel = ui->lineEdit_2->text();
    QString IDcard = ui->lineEdit_3->text();
    QString pwd = ui->lineEdit_4->text();
    QString mark = ui->lineEdit_5->text();

    if(userid == NULL || tel == NULL || IDcard == NULL || pwd == NULL || ui->lineEdit_5 == NULL) //插入信息的时候需要输入完整的信息
    {
        QMessageBox::information(NULL,"fail "," 信息写入失败！！ 请输入完整的信息");
    }
    else
    {
       QString str = QString("insert into usrlist (id,tel,IDcard,pwd,mark) values('%1','%2','%3','%4','%5') ").arg(userid).arg(tel).arg(IDcard).arg(pwd).arg(mark);
        QSqlQuery query;
        query.exec(str); //执行插入操作
        ui->lineEdit->clear();
        ui->lineEdit_2->clear();
        ui->lineEdit_3->clear();
        ui->lineEdit_4->clear();
        ui->lineEdit_5->clear();
        QMessageBox::information(NULL,"Success"," 信息写入成功！！");
    }
}

void Guanliyuanrenshiguanli::on_pushButton_4_clicked()
{
    QString id = ui->lineEdit->text();
    if(id ==  NULL)
    {
        QMessageBox::information(NULL,"fail"," 请输入需要删除的人的名字");//删除的时候需要输入姓名
    }
    else
    {
        //从数据库中查询是否有这个人
        QSqlQuery query;
        QString temp =  QString("select * from usrlist where id = '%1'").arg(id);
        query.exec(temp);
        QString deleteid;
        while (query.next())
        {
            deleteid = query.value(1).toString();
        }
        if(deleteid == NULL)
        {
            ui->lineEdit->clear();
            ui->lineEdit_2->clear();
            ui->lineEdit_3->clear();
            ui->lineEdit_4->clear();
            ui->lineEdit_5->clear();
            QString a = QString("没有叫%1的人，删除失败").arg(id);
            QMessageBox::information(NULL,"fail",a);
        }
        else
        {
            QString str =  QString("delete from usrlist where id = '%1'").arg(id);
            query.exec(str);//删除信息

            ui->lineEdit->clear();
            ui->lineEdit_2->clear();
            ui->lineEdit_3->clear();
            ui->lineEdit_4->clear();
            ui->lineEdit_5->clear();
            QMessageBox::information(NULL,"Success"," 信息删除成功！！");
        }
    }
}
