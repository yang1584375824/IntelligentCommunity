/********************************************************************************
** Form generated from reading UI file 'wuyejiaofeiguanli.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WUYEJIAOFEIGUANLI_H
#define UI_WUYEJIAOFEIGUANLI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Wuyejiaofeiguanli
{
public:
    QLabel *label_3;
    QTableView *tableView;
    QPushButton *pushButton_3;
    QLabel *label_4;
    QPushButton *pushButton;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit_2;

    void setupUi(QWidget *Wuyejiaofeiguanli)
    {
        if (Wuyejiaofeiguanli->objectName().isEmpty())
            Wuyejiaofeiguanli->setObjectName(QStringLiteral("Wuyejiaofeiguanli"));
        Wuyejiaofeiguanli->resize(700, 600);
        Wuyejiaofeiguanli->setStyleSheet(QStringLiteral("background-image: url();"));
        label_3 = new QLabel(Wuyejiaofeiguanli);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(20, 290, 72, 15));
        tableView = new QTableView(Wuyejiaofeiguanli);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(80, 310, 541, 211));
        pushButton_3 = new QPushButton(Wuyejiaofeiguanli);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(360, 250, 93, 28));
        label_4 = new QLabel(Wuyejiaofeiguanli);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(250, 20, 161, 91));
        pushButton = new QPushButton(Wuyejiaofeiguanli);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(170, 250, 93, 28));
        horizontalLayoutWidget_2 = new QWidget(Wuyejiaofeiguanli);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(90, 140, 451, 91));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_2->addWidget(label);

        lineEdit = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout_2->addWidget(lineEdit);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(horizontalLayoutWidget_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit_2 = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout->addWidget(lineEdit_2);


        horizontalLayout_2->addLayout(horizontalLayout);


        retranslateUi(Wuyejiaofeiguanli);

        QMetaObject::connectSlotsByName(Wuyejiaofeiguanli);
    } // setupUi

    void retranslateUi(QWidget *Wuyejiaofeiguanli)
    {
        Wuyejiaofeiguanli->setWindowTitle(QApplication::translate("Wuyejiaofeiguanli", "Form", Q_NULLPTR));
        label_3->setText(QApplication::translate("Wuyejiaofeiguanli", "\346\237\245\350\257\242\347\273\223\346\236\234", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Wuyejiaofeiguanli", "\346\234\252\347\274\264\350\264\271\346\237\245\350\257\242", Q_NULLPTR));
        label_4->setText(QApplication::translate("Wuyejiaofeiguanli", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; color:#0055ff;\">\347\274\264\350\264\271\344\277\241\346\201\257\346\237\245\350\257\242</span></p></body></html>", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Wuyejiaofeiguanli", "\346\237\245\350\257\242", Q_NULLPTR));
        label->setText(QApplication::translate("Wuyejiaofeiguanli", "\347\261\273\345\236\213", Q_NULLPTR));
        label_2->setText(QApplication::translate("Wuyejiaofeiguanli", "\346\227\266\351\227\264", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Wuyejiaofeiguanli: public Ui_Wuyejiaofeiguanli {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WUYEJIAOFEIGUANLI_H
