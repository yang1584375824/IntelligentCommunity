/********************************************************************************
** Form generated from reading UI file 'guanliyuanqingjiashenpi.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUANLIYUANQINGJIASHENPI_H
#define UI_GUANLIYUANQINGJIASHENPI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Guanliyuanqingjiashenpi
{
public:
    QPushButton *pushButton_2;
    QLabel *label;
    QLabel *label_7;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QLabel *label_6;
    QLineEdit *lineEdit_5;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QLineEdit *lineEdit_6;

    void setupUi(QWidget *Guanliyuanqingjiashenpi)
    {
        if (Guanliyuanqingjiashenpi->objectName().isEmpty())
            Guanliyuanqingjiashenpi->setObjectName(QStringLiteral("Guanliyuanqingjiashenpi"));
        Guanliyuanqingjiashenpi->resize(700, 601);
        Guanliyuanqingjiashenpi->setStyleSheet(QStringLiteral("background-image: url();"));
        pushButton_2 = new QPushButton(Guanliyuanqingjiashenpi);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(110, 530, 93, 28));
        label = new QLabel(Guanliyuanqingjiashenpi);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 50, 91, 51));
        label_7 = new QLabel(Guanliyuanqingjiashenpi);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(140, 440, 72, 15));
        label_2 = new QLabel(Guanliyuanqingjiashenpi);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(140, 370, 72, 15));
        lineEdit = new QLineEdit(Guanliyuanqingjiashenpi);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(220, 370, 113, 21));
        textEdit = new QTextEdit(Guanliyuanqingjiashenpi);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(30, 100, 641, 231));
        pushButton = new QPushButton(Guanliyuanqingjiashenpi);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(380, 530, 93, 28));
        label_6 = new QLabel(Guanliyuanqingjiashenpi);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(140, 410, 72, 15));
        lineEdit_5 = new QLineEdit(Guanliyuanqingjiashenpi);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(220, 410, 113, 21));
        pushButton_3 = new QPushButton(Guanliyuanqingjiashenpi);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(250, 530, 93, 28));
        pushButton_4 = new QPushButton(Guanliyuanqingjiashenpi);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(510, 530, 93, 28));
        lineEdit_6 = new QLineEdit(Guanliyuanqingjiashenpi);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(220, 440, 113, 21));

        retranslateUi(Guanliyuanqingjiashenpi);
        QObject::connect(pushButton_4, SIGNAL(clicked()), Guanliyuanqingjiashenpi, SLOT(close()));

        QMetaObject::connectSlotsByName(Guanliyuanqingjiashenpi);
    } // setupUi

    void retranslateUi(QWidget *Guanliyuanqingjiashenpi)
    {
        Guanliyuanqingjiashenpi->setWindowTitle(QApplication::translate("Guanliyuanqingjiashenpi", "Form", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\345\205\201\350\256\270", Q_NULLPTR));
        label->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\350\257\267\345\201\207\344\272\272\345\221\230\344\277\241\346\201\257", Q_NULLPTR));
        label_7->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\351\224\200\345\201\207\345\256\241\346\211\271", Q_NULLPTR));
        label_2->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\345\247\223\345\220\215", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\346\237\245\350\257\242", Q_NULLPTR));
        label_6->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\350\257\267\345\201\207\345\256\241\346\211\271", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\346\213\222\347\273\235", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("Guanliyuanqingjiashenpi", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Guanliyuanqingjiashenpi: public Ui_Guanliyuanqingjiashenpi {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUANLIYUANQINGJIASHENPI_H
