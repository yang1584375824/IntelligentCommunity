/********************************************************************************
** Form generated from reading UI file 'guanliyuanchushihua.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUANLIYUANCHUSHIHUA_H
#define UI_GUANLIYUANCHUSHIHUA_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_guanliyuanchushihua
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_2;

    void setupUi(QWidget *guanliyuanchushihua)
    {
        if (guanliyuanchushihua->objectName().isEmpty())
            guanliyuanchushihua->setObjectName(QStringLiteral("guanliyuanchushihua"));
        guanliyuanchushihua->resize(700, 600);
        guanliyuanchushihua->setStyleSheet(QStringLiteral("background-image: url();"));
        label = new QLabel(guanliyuanchushihua);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(230, 20, 191, 61));
        pushButton = new QPushButton(guanliyuanchushihua);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(200, 440, 241, 81));
        label_2 = new QLabel(guanliyuanchushihua);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(100, 60, 511, 321));

        retranslateUi(guanliyuanchushihua);

        QMetaObject::connectSlotsByName(guanliyuanchushihua);
    } // setupUi

    void retranslateUi(QWidget *guanliyuanchushihua)
    {
        guanliyuanchushihua->setWindowTitle(QApplication::translate("guanliyuanchushihua", "guanliyuanchushihua", Q_NULLPTR));
        label->setText(QApplication::translate("guanliyuanchushihua", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#5500ff;\">\347\263\273\347\273\237\345\210\235\345\247\213\345\214\226</span></p></body></html>", Q_NULLPTR));
        pushButton->setText(QApplication::translate("guanliyuanchushihua", "\347\241\256\345\256\232", Q_NULLPTR));
        label_2->setText(QApplication::translate("guanliyuanchushihua", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ff0000;\">\345\275\223\344\275\240\347\202\271\345\207\273\347\241\256\345\256\232\346\214\211\351\222\256\346\227\266\357\274\214\347\263\273\347\273\237\345\206\205\346\211\200\346\234\211\347\232\204\346\225\260\346\215\256\345\260\206\344\274\232\350\242\253\346\270\205\347\251\272\343\200\202</span></p><p><br/></p><p><span style=\" font-size:12pt; font-weight:600; color:#ff0000;\">\350\257\267\350\260\250\346\205\216\351\200\211\346\213\251\357\274\201\357\274\201</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class guanliyuanchushihua: public Ui_guanliyuanchushihua {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUANLIYUANCHUSHIHUA_H
