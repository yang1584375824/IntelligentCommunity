/********************************************************************************
** Form generated from reading UI file 'wuyerenyuanguanli.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WUYERENYUANGUANLI_H
#define UI_WUYERENYUANGUANLI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Wuyerenyuanguanli
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLabel *label_7;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_5;
    QLabel *label_8;
    QLineEdit *lineEdit_7;
    QLabel *label_9;
    QTextEdit *textEdit;
    QPushButton *pushButton_6;

    void setupUi(QWidget *Wuyerenyuanguanli)
    {
        if (Wuyerenyuanguanli->objectName().isEmpty())
            Wuyerenyuanguanli->setObjectName(QStringLiteral("Wuyerenyuanguanli"));
        Wuyerenyuanguanli->resize(700, 600);
        Wuyerenyuanguanli->setStyleSheet(QLatin1String("background-image: url();\n"
""));
        label = new QLabel(Wuyerenyuanguanli);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(220, 10, 201, 31));
        label_2 = new QLabel(Wuyerenyuanguanli);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 70, 72, 15));
        label_3 = new QLabel(Wuyerenyuanguanli);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(170, 70, 72, 15));
        label_4 = new QLabel(Wuyerenyuanguanli);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(300, 70, 72, 15));
        label_5 = new QLabel(Wuyerenyuanguanli);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(450, 70, 72, 15));
        label_6 = new QLabel(Wuyerenyuanguanli);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(20, 130, 81, 21));
        lineEdit = new QLineEdit(Wuyerenyuanguanli);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(70, 70, 81, 21));
        lineEdit_2 = new QLineEdit(Wuyerenyuanguanli);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(220, 70, 51, 21));
        lineEdit_3 = new QLineEdit(Wuyerenyuanguanli);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(350, 70, 71, 21));
        lineEdit_4 = new QLineEdit(Wuyerenyuanguanli);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(510, 70, 161, 21));
        lineEdit_5 = new QLineEdit(Wuyerenyuanguanli);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(140, 120, 491, 41));
        label_7 = new QLabel(Wuyerenyuanguanli);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(30, 480, 141, 21));
        lineEdit_6 = new QLineEdit(Wuyerenyuanguanli);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(190, 470, 131, 31));
        pushButton = new QPushButton(Wuyerenyuanguanli);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(40, 550, 93, 28));
        pushButton_2 = new QPushButton(Wuyerenyuanguanli);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(170, 550, 93, 28));
        pushButton_3 = new QPushButton(Wuyerenyuanguanli);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(300, 550, 93, 28));
        pushButton_5 = new QPushButton(Wuyerenyuanguanli);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(440, 550, 93, 28));
        label_8 = new QLabel(Wuyerenyuanguanli);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(370, 480, 91, 21));
        lineEdit_7 = new QLineEdit(Wuyerenyuanguanli);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(460, 470, 201, 31));
        label_9 = new QLabel(Wuyerenyuanguanli);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(20, 180, 101, 21));
        textEdit = new QTextEdit(Wuyerenyuanguanli);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(20, 210, 651, 241));
        pushButton_6 = new QPushButton(Wuyerenyuanguanli);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(570, 550, 93, 28));

        retranslateUi(Wuyerenyuanguanli);

        QMetaObject::connectSlotsByName(Wuyerenyuanguanli);
    } // setupUi

    void retranslateUi(QWidget *Wuyerenyuanguanli)
    {
        Wuyerenyuanguanli->setWindowTitle(QApplication::translate("Wuyerenyuanguanli", "Widget", Q_NULLPTR));
        label->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-size:18pt; font-weight:600; color:#000000;\">\344\270\232\344\270\273\347\231\273\350\256\260\347\256\241\347\220\206</span></p></body></html>", Q_NULLPTR));
        label_2->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-weight:600;\">\345\247\223\345\220\215</span></p></body></html>", Q_NULLPTR));
        label_3->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-weight:600;\">\345\271\264\351\276\204</span></p></body></html>", Q_NULLPTR));
        label_4->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-weight:600;\">\346\200\247\345\210\253</span></p></body></html>", Q_NULLPTR));
        label_5->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-weight:600;\">\346\211\213\346\234\272\345\217\267</span></p></body></html>", Q_NULLPTR));
        label_6->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">\345\256\266\345\272\255\344\275\217\345\235\200</span></p></body></html>", Q_NULLPTR));
        label_7->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">\350\257\267\350\276\223\345\205\245\346\237\245\350\257\242\344\277\241\346\201\257</span></p></body></html>", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Wuyerenyuanguanli", "\346\237\245\350\257\242", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Wuyerenyuanguanli", "\345\242\236\345\212\240\344\277\241\346\201\257", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Wuyerenyuanguanli", "\344\277\256\346\224\271", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("Wuyerenyuanguanli", "\345\210\240\351\231\244", Q_NULLPTR));
        label_8->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">\346\237\245\350\257\242\347\273\223\346\236\234</span></p></body></html>", Q_NULLPTR));
        label_9->setText(QApplication::translate("Wuyerenyuanguanli", "<html><head/><body><p><span style=\" font-size:11pt; font-weight:600;\">\346\210\220\345\221\230\344\277\241\346\201\257</span></p></body></html>", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("Wuyerenyuanguanli", "\346\210\220\345\221\230\344\277\241\346\201\257", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Wuyerenyuanguanli: public Ui_Wuyerenyuanguanli {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WUYERENYUANGUANLI_H
