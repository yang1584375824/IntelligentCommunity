/********************************************************************************
** Form generated from reading UI file 'canshushezhi.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CANSHUSHEZHI_H
#define UI_CANSHUSHEZHI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_canshushezhi
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QLabel *label_8;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLabel *label_6;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_10;
    QLabel *label_11;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_3;
    QLabel *label_7;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_4;
    QLabel *label_9;

    void setupUi(QWidget *canshushezhi)
    {
        if (canshushezhi->objectName().isEmpty())
            canshushezhi->setObjectName(QStringLiteral("canshushezhi"));
        canshushezhi->resize(700, 600);
        canshushezhi->setStyleSheet(QStringLiteral("background-image: url();"));
        layoutWidget = new QWidget(canshushezhi);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(49, 479, 611, 81));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout_3->addWidget(label_5);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_3->addWidget(label_8);

        layoutWidget1 = new QWidget(canshushezhi);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(40, 50, 441, 51));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setFrameShape(QFrame::NoFrame);

        horizontalLayout->addWidget(label_2);

        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout->addWidget(label_6);

        layoutWidget2 = new QWidget(canshushezhi);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(39, 119, 431, 61));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_10 = new QLabel(layoutWidget2);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_2->addWidget(label_10);

        label_11 = new QLabel(layoutWidget2);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_2->addWidget(label_11);

        layoutWidget3 = new QWidget(canshushezhi);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(39, 199, 521, 66));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget3);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_4->addWidget(label_3);

        label_7 = new QLabel(layoutWidget3);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_4->addWidget(label_7);

        layoutWidget4 = new QWidget(canshushezhi);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(40, 290, 611, 141));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(layoutWidget4);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_5->addWidget(label_4);

        label_9 = new QLabel(layoutWidget4);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_5->addWidget(label_9);


        retranslateUi(canshushezhi);

        QMetaObject::connectSlotsByName(canshushezhi);
    } // setupUi

    void retranslateUi(QWidget *canshushezhi)
    {
        canshushezhi->setWindowTitle(QApplication::translate("canshushezhi", "canshushezhi", Q_NULLPTR));
        label_5->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600; color:#5500ff;\">Url</span></p></body></html>", Q_NULLPTR));
        label_8->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:11pt;\">https://github.com/yang1584375824/IntelligentCommunity</span></p></body></html>", Q_NULLPTR));
        label_2->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600; color:#5500ff;\">Group name</span></p></body></html>", Q_NULLPTR));
        label_6->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">\344\270\200\347\273\204</span></p></body></html>", Q_NULLPTR));
        label_10->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600; color:#5500ff;\">PM</span></p></body></html>", Q_NULLPTR));
        label_11->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">\351\251\254\350\203\234\346\200\273</span></p></body></html>", Q_NULLPTR));
        label_3->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600; color:#5500ff;\">Team members</span></p></body></html>", Q_NULLPTR));
        label_7->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">\351\203\255\344\270\275 \344\276\257\346\241\202\346\236\227 \351\251\254\350\203\234\346\200\273 \347\216\213\345\207\241 </span></p><p><span style=\" font-size:14pt; font-weight:600;\">\347\216\213\345\255\246\345\243\256 \350\247\243\347\216\211\346\210\220 \346\235\250\346\210\220\345\235\244 \345\274\240\345\223\262</span></p></body></html>", Q_NULLPTR));
        label_4->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:14pt; font-weight:600; color:#5500ff;\">Introduction</span></p></body></html>", Q_NULLPTR));
        label_9->setText(QApplication::translate("canshushezhi", "<html><head/><body><p><span style=\" font-size:11pt;\">\346\234\254\344\272\247\345\223\201\346\231\272\346\205\247\345\260\217\345\214\272\357\274\214\344\273\216\344\270\232\344\270\273\343\200\201\347\211\251\344\270\232\343\200\201\347\211\251\344\270\232\347\256\241\347\220\206\345\221\230\344\270\211\344\270\252</span></p><p><span style=\" font-size:11pt;\">\350\247\222\345\272\246\350\256\276\350\256\241\357\274\214\345\257\271\347\244\276\345\214\272\344\277\241\346\201\257\350\277\233\350\241\214\347\273\264\346\212\244\345\222\214\347\256\241\347\220\206\357\274\214\346\227\242\346\226\271\344\276\277</span></p><p><span style=\" font-size:11pt;\">\345\257\271\344\270\232\344\270\273\347\232\204\347\256\241\347\220\206\357\274\214\344\271\237\346\226\271\344\276\277\344\272\206\344\270\232\344\270\273\347\232\204\347\224\237\346\264\273\343\200\202</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class canshushezhi: public Ui_canshushezhi {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CANSHUSHEZHI_H
