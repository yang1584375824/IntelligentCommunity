#include "admin_mainwindow.h"
#include "ui_admin_mainwindow.h"
#include "guanliyuanrenshiguanli.h"
#include "ui_guanliyuanrenshiguanli.h"

admin_MainWindow::admin_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::admin_MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("管理员管理面板");
    this->setWindowIcon(QIcon(":/logo.png"));
    Guanliyuanrenshiguanli *guanliyuanrenshiguanli = new Guanliyuanrenshiguanli;
    this->setCentralWidget(guanliyuanrenshiguanli);
}

admin_MainWindow::~admin_MainWindow()
{
    delete ui;
}

void admin_MainWindow::on_action_triggered()//人事管理
{
    Guanliyuanrenshiguanli *guanliyuanrenshiguanli = new Guanliyuanrenshiguanli;
    this->setCentralWidget(guanliyuanrenshiguanli);
}
