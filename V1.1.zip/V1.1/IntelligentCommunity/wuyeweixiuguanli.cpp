#include "wuyeweixiuguanli.h"
#include "ui_wuyeweixiuguanli.h"

Wuyeweixiuguanli::Wuyeweixiuguanli(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyeweixiuguanli)
{
    ui->setupUi(this);

/**连接数据库**/
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("wuye.db");
    if(!db.open()){
        QMessageBox::information(NULL,"提示","数据库连接失败",QMessageBox::Ok);
    }else{
        QMessageBox::information(NULL,"提示","数据库连接成功",QMessageBox::Ok);
    }
}

Wuyeweixiuguanli::~Wuyeweixiuguanli()
{
    delete ui;
}

void Wuyeweixiuguanli::on_pushButton_clicked()
{
          model = new QSqlTableModel(this);
          model->setTable("weixiu");
          model->select();
          model->setEditStrategy(QSqlTableModel::OnManualSubmit);
          ui->tableView->setModel(model);

}

void Wuyeweixiuguanli::on_pushButton_3_clicked()
{
    // 获取选中的行
    int curRow = ui->tableView->currentIndex().row();

    // 删除该行
    model->removeRow(curRow);
    int ok = QMessageBox::warning(this,tr("删除当前行!"),
                                  tr("你确定删除当前行吗？"), QMessageBox::Yes, QMessageBox::No);
    if(ok == QMessageBox::No)
    { // 如果不删除，则撤销
        model->revertAll();
    } else { // 否则提交，在数据库中删除该行
        model->submitAll();
    }
}

void Wuyeweixiuguanli::on_pushButton_4_clicked()
{
    QString searchname = ui->lineEdit->text();
    if(searchname==NULL)
    {
         QMessageBox::information(NULL,"提示","请输入查询姓名",QMessageBox::Ok);
    }
    else
    {
        QString str=QString("select * from weixiu where name = '%1'").arg(searchname);
        QSqlQuery query;
        if(!query.exec(str))
        {
            qDebug()<<"there is not a table of weixiu in mysql"<<query.lastError();
        }
        QString tel,add,pro,bao,jin,pin;
        while(query.next())
        {
            tel=query.value(2).toString();
            add=query.value(3).toString();
            pro=query.value(4).toString();
            bao=query.value(5).toString();
            jin=query.value(6).toString();
            pin=query.value(7).toString();

            ui->lineEdit_2->setText(tel);
            ui->lineEdit_3->setText(add);
            ui->textEdit->setText(pro);
            ui->lineEdit_4->setText(bao);
            ui->lineEdit_5->setText(jin);
            ui->lineEdit_6->setText(pin);
            ui->lineEdit_6->setFocusPolicy(Qt::NoFocus);
        }

    }
}

void Wuyeweixiuguanli::on_pushButton_2_clicked()
{
    QString qingkuang = ui->lineEdit_4->text();
    QString jindu = ui->lineEdit_5->text();
    QString searchname = ui->lineEdit->text();
    if(searchname == NULL )
    {
         QMessageBox::information(NULL,"fail"," 请输入需要修改的人的姓名、情况、进度");
    }
    else
    {
         QString temp = QString("update weixiu set qingkuang = '%1' , jindu = '%2' where name = '%3'").arg(qingkuang).arg(jindu).arg(searchname);
         QSqlQuery query;
         query.exec(temp);
         QMessageBox::information(NULL,"Success"," 信息修改成功!!");
        }
}

