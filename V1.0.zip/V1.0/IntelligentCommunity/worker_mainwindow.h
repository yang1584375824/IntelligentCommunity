#ifndef WORKER_MAINWINDOW_H
#define WORKER_MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class worker_MainWindow;
}

class worker_MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit worker_MainWindow(QWidget *parent = 0);
    ~worker_MainWindow();

private slots:
    void on_action_triggered();

    void on_actionrenshi_triggered();

private:
    Ui::worker_MainWindow *ui;
};

#endif // WORKER_MAINWINDOW_H
