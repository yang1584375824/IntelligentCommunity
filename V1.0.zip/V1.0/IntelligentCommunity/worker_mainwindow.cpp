#include "worker_mainwindow.h"
#include "ui_worker_mainwindow.h"
#include "wuyerenshi.h"
#include "wuyerenyuanguanli.h"
#include "ui_wuyerenyuanguanli.h"

worker_MainWindow::worker_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::worker_MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("物业管理面板");
    this->setWindowIcon(QIcon(":/logo.png"));
    Wuyerenyuanguanli *wuyerenyuanguan = new Wuyerenyuanguanli;
    this->setCentralWidget(wuyerenyuanguan);
}

worker_MainWindow::~worker_MainWindow()
{
    delete ui;
}

void worker_MainWindow::on_action_triggered()
{
//    Wuyerenshi *wuyeshi = new Wuyerenshi;
//    setCentralWidget(wuyeshi);
    Wuyerenyuanguanli *wuyerenyuanguan = new Wuyerenyuanguanli;
    this->setCentralWidget(wuyerenyuanguan);

}

void worker_MainWindow::on_actionrenshi_triggered()
{
//    Test_2 *test = new Test_2;
//    this->setCentralWidget(test);
}
