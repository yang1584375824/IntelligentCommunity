#include "owner_mainwindow.h"
#include "ui_owner_mainwindow.h"

Owner_MainWindow::Owner_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Owner_MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("业主管理面板");
    this->setWindowIcon(QIcon(":/logo.png"));
}

Owner_MainWindow::~Owner_MainWindow()
{
    delete ui;
}
