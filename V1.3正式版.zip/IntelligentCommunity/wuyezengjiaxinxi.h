#ifndef WUYEZENGJIAXINXI_H
#define WUYEZENGJIAXINXI_H

#include <QWidget>

namespace Ui {
class wuyezengjiaxinxi;
}

class wuyezengjiaxinxi : public QWidget
{
    Q_OBJECT

public:
    explicit wuyezengjiaxinxi(QWidget *parent = 0);
    ~wuyezengjiaxinxi();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::wuyezengjiaxinxi *ui;
};

#endif // WUYEZENGJIAXINXI_H
