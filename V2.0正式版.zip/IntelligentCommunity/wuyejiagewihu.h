#ifndef PRICE_H
#define PRICE_H

#include <QWidget>

namespace Ui {
class Wuyejiagewihu;
}

class Wuyejiagewihu : public QWidget
{
    Q_OBJECT

public:
    explicit Wuyejiagewihu(QWidget *parent = 0);
    ~Wuyejiagewihu();
private slots:
    void on_pushButton_clicked();

private:
    Ui::Wuyejiagewihu *ui;
};

#endif // PRICE_H
