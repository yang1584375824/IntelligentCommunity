#include "yezhuzizhujiaofei.h"
#include "ui_yezhuzizhujiaofei.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>
#include <QWidget>
extern int yonghuming;
yezhuzizhujiaofei::yezhuzizhujiaofei(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::yezhuzizhujiaofei)
{
    ui->setupUi(this);
}

yezhuzizhujiaofei::~yezhuzizhujiaofei()
{
    delete ui;
}
void yezhuzizhujiaofei::on_pushButton_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel(this);

    QString sql = QString("select payment.*,typer.number from payment inner join typer on payment.id=typer.userid and payment.type=typer.type and payment.date=typer.date where id=%1 and state = '%2'").arg(yonghuming).arg("否");
    model->setQuery(sql);
    qDebug()<<model->rowCount();
    model->setHeaderData(0,Qt::Horizontal,"id");
    model->setHeaderData(1,Qt::Horizontal,"姓名");
    model->setHeaderData(2,Qt::Horizontal,"类型");
    model->setHeaderData(3,Qt::Horizontal,"日期");
    model->setHeaderData(4,Qt::Horizontal,"是否缴费");
    model->setHeaderData(5,Qt::Horizontal,"缴费数量");
    ui->tableView->setModel(model);


}

void yezhuzizhujiaofei::on_pushButton_2_clicked()
{

    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString type = ui->comboBox->currentText();
    QString date = ui->lineEdit_6->text();
    QString sql = QString("update payment set state = '%1' where id = %2 and type = '%3' and date = '%4'").arg("是").arg(yonghuming).arg(type).arg(date);
    model->setQuery(sql);


    ui->lineEdit_6->clear();
    QMessageBox::information(NULL,"Success"," 缴费成功！！");
}
