#include "wuyeshangxiabandengji.h"
#include "ui_wuyeshangxiabandengji.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>

extern int yonghuming;

Wuyeshangxiabandengji::Wuyeshangxiabandengji(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wuyeshangxiabandengji)
{
    ui->setupUi(this);
    //建立并打开数据库
//        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
//        db.setDatabaseName("shangban.db");
//    if (!db.open()) {
//        QMessageBox::critical(nullptr, QObject::tr("未找到需要的数据库文件"),
//            QObject::tr("不能建立链接n.\n"
//                        "This example needs SQLite support. Please read "
//                        "the Qt SQL driver documentation for information how "
//                        "to build it.\n\n"
//                        "Click Cancel to exit."), QMessageBox::Cancel);
//    }else{
//        qDebug()<<"数据库打开成功！ "<<endl;
//      //  ui->label_data->setText(tr("数据库打开成功"));
//    }
}

Wuyeshangxiabandengji::~Wuyeshangxiabandengji()
{
    delete ui;
}

void Wuyeshangxiabandengji::on_pushButton_clicked()
{
    QString str1=QString("select * from usrlist where id = '%1'").arg(yonghuming);
    QSqlQuery query1;
    query1.exec(str1);
    QString namel;
    while(query1.next())
    {
        namel=query1.value(5).toString();
    }
    QString shangban = ui->lineEdit_2->text();
    //QString xiaban = ui->lineEdit_3->text();
    QString date = ui->lineEdit_4->text();
    QString str = QString("insert into chuqin (name,shangban,date) values('%1','%2','%3') ").arg(namel).arg(shangban).arg(date);
    QSqlQuery query;

        if(!query.exec(str))
        {
             qDebug()<<"there is not a table of chuqin in mysql!"<<query.lastError();
        }
        else
        {
            QMessageBox::information(NULL,"Success"," 上班时间已写入！！");
}
}

void Wuyeshangxiabandengji::on_pushButton_2_clicked()
{

    QString str1=QString("select * from usrlist where id = '%1'").arg(yonghuming);
    QSqlQuery query1;
    query1.exec(str1);
    QString namel;
    while(query1.next())
    {
        namel=query1.value(5).toString();
    }
    QString updatexiaban = ui->lineEdit_3->text();

         QString temp = QString("update chuqin set xiaban = '%1' where name = '%2'").arg(updatexiaban).arg(namel);
         QSqlQuery query;
         query.exec(temp);
         QMessageBox::information(NULL,"Success"," 下班时间已写入!!");
            ui->lineEdit_3->clear();
        }
