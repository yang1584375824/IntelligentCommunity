#ifndef QUANJU_H
#define QUANJU_H

extern int yonghuming;
int yonghuming = 0;
extern int theme;
int theme = 0;

#endif // QUANJU_H
